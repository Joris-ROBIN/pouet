void print_tab(unsigned char*);
int count_string (unsigned char*);